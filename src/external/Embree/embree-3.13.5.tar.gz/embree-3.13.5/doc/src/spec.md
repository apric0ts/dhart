Introduction
============

``` {include=src/intro.md}
```
\pagebreak

Embree API
==========

``` {include=src/api-ref.md}
```
\pagebreak
